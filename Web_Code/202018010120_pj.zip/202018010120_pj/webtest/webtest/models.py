import mysql.connector


class Product:
    def __init__(self, id, name, image, description, price, inventory, supplier_id, category_id, discount=None,
                 discount_time=None):
        self.id = id
        self.name = name
        self.image = image
        self.description = description
        self.price = price
        self.inventory = inventory
        self.supplier_id = supplier_id
        self.category_id = category_id
        self.discount = discount
        self.discount_time = discount_time

    def __str__(self):
        return f"Product(id={self.id}, name={self.name}, price={self.price}, discount={self.discount})"

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "image": self.image,
            "description": self.description,
            "price": float(self.price),
            "inventory": self.inventory,
            "supplier_id": self.supplier_id,
            "category_id": self.category_id,
            "discount": self.discount,
            "discount_time": self.discount_time
        }


class Supplier:
    def __init__(self, user_id, username, password, email, address, phone,is_admin=False):
        self.user_id = user_id
        self.username = username
        self.password = password
        self.email = email
        self.address = address
        self.phone = phone
        self.is_admin = is_admin


class Category:
    def __init__(self, id, name):
        self.id = id
        self.name = name


class Customer:
    def __init__(self, user_id, username, password, email, address, phone,is_admin=False):
        self.user_id = user_id
        self.username = username
        self.password = password
        self.address = address
        self.email = email
        self.phone = phone
        self.is_admin = is_admin


class CartItem:
    def __init__(self, cart_id, user_id, product_id, quantity):
        self.cart_id = cart_id
        self.user_id = user_id
        self.product_id = product_id
        self.quantity = quantity

    def __str__(self):
        return f"CartItem(cart_id={self.cart_id}, user_id={self.user_id}, product_id={self.product_id}, quantity={self.quantity})"


# models.py
class Order:
    def __init__(self, order_id, user_id, product_id, supplier_id, quantity, status, price, payment_method, time,
                 receiver_name, receiver_address, receiver_phone, external_id):
        self.order_id = order_id
        self.user_id = user_id
        self.product_id = product_id
        self.supplier_id = supplier_id
        self.quantity = quantity
        self.status = status
        self.price = price
        self.payment_method = payment_method
        self.time = time
        self.receiver_name = receiver_name
        self.receiver_address = receiver_address
        self.receiver_phone = receiver_phone
        self.external_id = external_id


class Comment:
    def __init__(self, comment_id, customer_id, product_id, content, time):
        self.comment_id = comment_id
        self.customer_id = customer_id
        self.product_id = product_id
        self.content = content
        self.time = time

