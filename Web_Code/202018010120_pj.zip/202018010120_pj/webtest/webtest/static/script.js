
document.addEventListener("DOMContentLoaded", function () {
    let index = 0;
    const slides = document.querySelectorAll(".swiper-slide");
    const slideCount = slides.length;

    function showSlide() {
        const wrapper = document.querySelector(".swiper-wrapper");
        wrapper.style.transform = `translateX(-${index * 100}%)`;
        updatePagination();
    }

    function nextSlide() {
        index = (index + 1) % slideCount;
        showSlide();
    }

    function prevSlide() {
        index = (index - 1 + slideCount) % slideCount;
        showSlide();
    }

    // document.querySelector(".swiper-button-next").addEventListener("click", nextSlide);
    // document.querySelector(".swiper-button-prev").addEventListener("click", prevSlide);

    function createPaginationButtons() {
        const pagination = document.querySelector(".swiper-pagination");

        for (let i = 0; i < slideCount; i++) {
            const button = document.createElement("button");
            button.addEventListener("click", () => {
                index = i;
                showSlide();
            });
            pagination.appendChild(button);
        }
    }

    function updatePagination() {
        const buttons = document.querySelectorAll(".swiper-pagination button");
        buttons.forEach((button, i) => {
            if (i === index) {
                button.classList.add("active");
            } else {
                button.classList.remove("active");
            }
        });
    }

    createPaginationButtons();
    updatePagination();

    setInterval(nextSlide, 3000);
});


