import os
import uuid

import mysql.connector
from werkzeug.utils import secure_filename
from models import Product, Supplier, Category, Customer, CartItem, Order, Comment

HOMENAME = "127.0.0.1"

PORT = 3306

USERNAME = "root"

PASSWORD = "1277514863"

DATABASE = "pj2"


def get_db_connection():
    return mysql.connector.connect(
        host=HOMENAME,
        user=USERNAME,
        password=PASSWORD,
        database=DATABASE
    )


def get_all_products():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM product")
    products = [Product(*row) for row in cursor.fetchall()]
    conn.close()
    return products


def get_product_by_id(product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM product WHERE id = %s", (product_id,))
    product = Product(*cursor.fetchone())
    conn.close()
    return product


def get_product_by_supplier_id(supplier_id):
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT id, name, image, description, price, inventory, supplier_id, category_id, discount, discount_time
        FROM product
        WHERE supplier_id = %s
    """, (supplier_id,))

    products = []
    for row in cursor.fetchall():
        product = Product(*row)
        products.append(product)

    return products


def add_supplier(supplier):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO supplier (username, password, email, address, phone) VALUES (%s, %s, %s, %s, %s)",
                   (supplier.username, supplier.password, supplier.email, supplier.address, supplier.phone))
    conn.commit()
    conn.close()


def get_supplier_by_id(supplier_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM supplier WHERE id = %s", (supplier_id,))
    supplier = Supplier(*cursor.fetchone())
    conn.close()
    return supplier


def get_supplier_by_username(username):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM supplier WHERE username = %s", (username,))
    result = cursor.fetchone()
    conn.close()

    if result:
        supplier = Supplier(
            user_id=result[0],
            username=result[1],
            password=result[2],
            email=result[3],
            address=result[4],
            phone=result[5]
        )
        return supplier
    else:
        return None


def add_customer(customer):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO customer (username, password, email, address, phone) VALUES (%s, %s, %s, %s, %s)",
                   (customer.username, customer.password, customer.email, customer.address, customer.phone))
    conn.commit()
    conn.close()


def get_customer_by_username(username):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Customer WHERE username = %s", (username,))
    result = cursor.fetchone()
    conn.close()
    if result:
        customer = Customer(
            user_id=result[0],
            username=result[1],
            password=result[2],
            address=result[3],
            email=result[4],
            phone=result[5]
        )
        return customer
    else:
        return None


def get_customer_by_id(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM customer WHERE id = %s",
        (user_id,)
    )
    customer = Customer(*cursor.fetchone())
    cursor.close()
    conn.close()
    return customer


def add_product_to_cart(user_id, product_id, quantity):
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute(
        'SELECT Quantity FROM cartitem WHERE UserID=%s AND ProductID=%s',
        (user_id, product_id)
    )
    result = cursor.fetchone()

    cursor.fetchall()

    if result:
        new_quantity = result[0] + quantity
        cursor.execute(
            'UPDATE cartitem SET Quantity=%s WHERE UserID=%s AND ProductID=%s',
            (new_quantity, user_id, product_id)
        )
    else:
        cursor.execute(
            'INSERT INTO cartitem (UserID, ProductID, Quantity) VALUES (%s, %s, %s)',
            (user_id, product_id, quantity)
        )

    connection.commit()
    cursor.close()
    connection.close()


def remove_product_from_cart(user_id, product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM cartitem WHERE UserID = %s AND ProductID = %s", (user_id, product_id))
    conn.commit()
    conn.close()


def update_product_quantity_in_cart(user_id, product_id, quantity):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE cartitem SET Quantity = %s WHERE UserID = %s AND ProductID = %s",
                   (quantity, user_id, product_id))
    conn.commit()
    conn.close()


def get_cart_items(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM cartitem WHERE UserID = %s", (user_id,))
    results = cursor.fetchall()
    conn.close()

    cart_items = []
    for result in results:
        cart_item = CartItem(
            cart_id=result[0],
            user_id=result[1],
            product_id=result[2],
            quantity=result[3]
        )
        cart_items.append(cart_item)
    return cart_items


def get_products_in_cart(user_id):
    cart_items = get_cart_items(user_id)

    products_in_cart = []
    for item in cart_items:
        product = get_product_by_id(item.product_id)
        products_in_cart.append({
            'product': product,
            'quantity': item.quantity
        })
    return products_in_cart


def update_product_quantity_in_cart(user_id, product_id, new_quantity):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE cartitem SET Quantity=%s WHERE UserID=%s AND ProductID=%s",
        (new_quantity, user_id, product_id)
    )
    conn.commit()
    cursor.close()
    conn.close()


def remove_product_from_cart(user_id, product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "DELETE FROM cartitem WHERE UserID=%s AND ProductID=%s",
        (user_id, product_id)
    )
    conn.commit()
    cursor.close()
    conn.close()


def remove_cart_items(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM cartitem WHERE UserID=%s", (user_id,))
    conn.commit()

    cursor.close()
    conn.close()


def insert_order(user_id, product_id, supplier_id, quantity, status, price, payment_method, time, receiver_name,
                 receiver_address, receiver_phone, external_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    insert_order_query = """
    INSERT INTO `order` (UserID, ProductID, SupplierID, Quantity, Status, Price, Payment_method, Time, Receiver_name, Receiver_address, Receiver_phone, external_id)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """

    cursor.execute(insert_order_query, (
        user_id, product_id, supplier_id, quantity, status, price, payment_method, time, receiver_name,
        receiver_address,
        receiver_phone, external_id))

    conn.commit()
    cursor.close()
    conn.close()


def get_orders_by_user_id(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM `order` WHERE UserID = %s",
        (user_id,)
    )
    orders = cursor.fetchall()
    cursor.close()
    conn.close()

    return orders


def get_orders_by_user_id(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM `order` WHERE UserID = %s",
        (user_id,)
    )
    order_tuples = cursor.fetchall()
    cursor.close()
    conn.close()

    orders = [Order(*order_tuple) for order_tuple in order_tuples]

    def get_status_priority(order):
        if order.status == 2:
            return 1
        elif order.status == 1:
            return 2
        elif order.status == 3:
            return 3
        else:
            return 4

    orders = sorted(orders, key=get_status_priority)

    return orders



def get_comments_by_product_id(product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Comment WHERE ProductID = %s", (product_id,))
    results = cursor.fetchall()
    conn.close()

    comments = [Comment(*comment_tuple) for comment_tuple in results]
    return comments


def insert_comment(user_id, product_id, content):
    conn = get_db_connection()
    cursor = conn.cursor()
    insert_comment_query = """
    INSERT INTO comment (CustomerID, ProductID, Content, Time)
    VALUES (%s, %s, %s, NOW())
    """

    cursor.execute(insert_comment_query, (user_id, product_id, content))
    conn.commit()
    cursor.close()
    conn.close()


def check_like(user_id, product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM `Like` WHERE UserID = %s AND ProductID = %s", (user_id, product_id))
    result = cursor.fetchone()
    conn.close()
    return bool(result)


def check_dislike(user_id, product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Dislike WHERE UserID = %s AND ProductID = %s", (user_id, product_id))
    result = cursor.fetchone()
    conn.close()
    return bool(result)


def add_like(user_id, product_id):
    if not check_like(user_id, product_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO `Like` (UserID, ProductID) VALUES (%s, %s)", (user_id, product_id))
        conn.commit()
        conn.close()


def remove_like(user_id, product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM `Like` WHERE UserID = %s AND ProductID = %s", (user_id, product_id))
    conn.commit()
    conn.close()


def add_dislike(user_id, product_id):
    if not check_dislike(user_id, product_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Dislike (UserID, ProductID) VALUES (%s, %s)", (user_id, product_id))
        conn.commit()
        conn.close()


def remove_dislike(user_id, product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Dislike WHERE UserID = %s AND ProductID = %s", (user_id, product_id))
    conn.commit()
    conn.close()


def get_likes_count(product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM `Like` WHERE ProductID = %s", (product_id,))
    likes = cursor.fetchone()[0]
    conn.close()
    return likes


def get_dislikes_count(product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM Dislike WHERE ProductID = %s", (product_id,))
    dislikes = cursor.fetchone()[0]
    conn.close()
    return dislikes


def update_like_dislike(user_id, product_id, action):
    liked = check_like(user_id, product_id)
    disliked = check_dislike(user_id, product_id)

    if action == "like":
        if liked:
            remove_like(user_id, product_id)
        else:
            if disliked:
                remove_dislike(user_id, product_id)
            add_like(user_id, product_id)
    elif action == "dislike":
        if disliked:
            remove_dislike(user_id, product_id)
        else:
            if liked:
                remove_like(user_id, product_id)
            add_dislike(user_id, product_id)

    likes = get_likes_count(product_id)
    dislikes = get_dislikes_count(product_id)

    return likes, dislikes


def update_product_inventory(product_id, quantity):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute('UPDATE product SET inventory = inventory - %s WHERE id = %s', (quantity, product_id))
    connection.commit()


def is_inventory_sufficient(product_id, quantity):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute('SELECT inventory FROM product WHERE id = %s', (product_id,))
    inventory = cursor.fetchone()[0]
    return inventory >= quantity


def get_all_categories():
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM category')
    return [Category(*row) for row in cursor.fetchall()]


def get_products_by_category(category_name):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT id FROM category WHERE name = %s", (category_name,))
    category_id_result = cursor.fetchone()
    if category_id_result is None:
        return []
    category_id = category_id_result[0]
    cursor.execute("SELECT * FROM product WHERE category_id = %s", (category_id,))
    product_rows = cursor.fetchall()
    products = [Product(*row) for row in product_rows]
    return products


def save_image(image):
    images_folder = os.path.join('static', 'images')
    if not os.path.exists(images_folder):
        os.makedirs(images_folder)

    unique_filename = f"{uuid.uuid4().hex}_{image.filename}"
    image_path = os.path.join(images_folder, unique_filename)
    image.save(image_path)

    return os.path.join('images', unique_filename)


def add_product_to_database(name, price, inventory, description, image_path, supplier_id, category_id, discount,
                            discount_time):
    connection = get_db_connection()
    cursor = connection.cursor()

    add_product_query = ("INSERT INTO wad.product "
                         "(name, price, inventory, description, image, supplier_id, category_id, discount, discount_time) "
                         "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)")

    cursor.execute(add_product_query,
                   (name, price, inventory, description, image_path, supplier_id, category_id, discount, discount_time))
    connection.commit()
    cursor.close()


def delete_product_from_database(product_id):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute('SELECT image FROM product WHERE id = %s', (product_id,))
    result = cursor.fetchone()

    if result:
        image_path = result[0]
    else:
        image_path = None

    cursor.execute('DELETE FROM product WHERE id = %s', (product_id,))
    connection.commit()

    return image_path


def update_product_in_database(product_id, name, price, inventory, description, image_path, category_id, discount,
                               discount_time):
    product = get_product_by_id(product_id)

    if product.image != image_path:
        old_image_path = os.path.join('static', product.image)
        if os.path.exists(old_image_path):
            os.remove(old_image_path)

    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute('''UPDATE product
                      SET name = %s, price = %s, inventory = %s, description = %s, image = %s, category_id = %s, discount = %s, discount_time = %s
                      WHERE id = %s''',
                   (name, price, inventory, description, image_path, category_id, discount, discount_time, product_id))
    connection.commit()


def get_orders_by_supplier_id(supplier_id):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM `order` WHERE SupplierID = %s', (supplier_id,))
    orders_data = cursor.fetchall()
    orders = [Order(*order_data) for order_data in orders_data]

    def get_status_priority(order):
        if order.status == 1:
            return 1
        elif order.status == 2:
            return 2
        elif order.status == 3:
            return 3
        else:
            return 4
    orders = sorted(orders, key=get_status_priority)
    return orders


def add_customer_name_to_orders(orders):
    orders_with_customer_name = []
    for order in orders:
        customer = get_customer_by_id(order.user_id)
        order_data = {
            'order_id': order.order_id,
            'customer_name': customer.username,
            'product_id': order.product_id,
            'supplier_id': order.supplier_id,
            'quantity': order.quantity,
            'status': order.status,
            'price': order.price,
            'payment_method': order.payment_method,
            'time': order.time,
            'receiver_name': order.receiver_name,
            'receiver_address': order.receiver_address,
            'receiver_phone': order.receiver_phone
        }
        orders_with_customer_name.append(order_data)
    return orders_with_customer_name


def delete_order_by_order_id(order_id):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute('DELETE FROM `order` WHERE OrderID = %s', (order_id,))
    connection.commit()
    return {"success": True}


def update_order_status(order_id, status):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute('UPDATE `order` SET Status = %s WHERE OrderID = %s', (status, order_id))
    connection.commit()
    affected_rows = cursor.rowcount

    return affected_rows > 0


def update_order_status_by_external_id(external_id, status):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute('UPDATE `order` SET Status = %s WHERE external_id = %s', (status, external_id))
    connection.commit()
    affected_rows = cursor.rowcount

    return affected_rows > 0

def get_category_by_id(category_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM category WHERE id = %s",
        (category_id,)
    )
    category = Category(*cursor.fetchone())
    cursor.close()
    conn.close()
    return category

