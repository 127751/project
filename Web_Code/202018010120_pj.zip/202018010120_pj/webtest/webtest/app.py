import os
from datetime import datetime
import uuid
from flask import render_template, redirect, url_for, jsonify, session, make_response
from flask import Flask, request
from models import Product, Supplier, Category, Customer, CartItem, Order
from database import get_db_connection, get_all_products, get_product_by_id, \
    add_supplier, get_supplier_by_username, add_customer, get_customer_by_username, add_product_to_cart, \
    remove_product_from_cart, update_product_quantity_in_cart, get_cart_items, get_products_in_cart, insert_order, \
    remove_cart_items, get_orders_by_user_id, get_customer_by_id, get_supplier_by_id, get_comments_by_product_id, \
    insert_comment, update_like_dislike, get_likes_count, get_dislikes_count, update_product_inventory, \
    is_inventory_sufficient, get_products_by_category, save_image, add_product_to_database, get_all_categories, \
    get_product_by_supplier_id, delete_product_from_database, update_product_in_database, get_orders_by_supplier_id, \
    add_customer_name_to_orders, delete_order_by_order_id, update_order_status, get_category_by_id, \
    update_order_status_by_external_id
from alipay import AliPay
import mysql.connector

from Cryptodome.PublicKey import RSA

app = Flask(__name__)
app.secret_key = '123'

app_id = '2021000122692050'
private_key_string = """-----BEGIN RSA PRIVATE KEY-----
MIIEpQIBAAKCAQEAg6HEAB58oDwHLu+4MZyOSj8nH7JY3er5dLWJcQj6MXOgYcl/IGOoLk9OUBCHs2NAf/KdlUxnYXMKg44dVrMv4/jr+LQxhoxFzmo2T51fJBYCsPHqkZMhQq3lEsslI0D/H0RDqbYwS4Ugk3lqrgqgb5BtEGdE8L5t51+TRF5B5/B5CEaE8rhhjO4l2ZYqAzSrZlqDkSfZ4QWZTFVJu4ByRT8wBKYeSDGZrrWu/1A4GAPhVBS5dJ6DmjEGO8rJhxT51a01+KN7Oid8Asn8/ioIHOHF9tdduomxRpERQm+faMKumcG0VgelS1t/48wxEnZBPIVScyfNTiBchsXVA+h4AQIDAQABAoIBAQCDiZllTRHYxWOgQajc2sdN5oHgKMapLHAPcoFf1Uq/M/5m+YXyBeRAMrvdQkd4uYvwz68tTGZaeS1efRtQUktfEpYrt1VuUKpJNNYFBQvX8a7Kx1RSGKa6DS/Gcf4wlnja88pxwz/Ll8MP29sBBFmCYt6575hywrjs5xMw1MgjTza66R0fwO36cYdrgXkMeO9Dc0U6nXgXOQKnjB8SAbQIcnoXy7Lpf0R0gRSH6ScMRoj5CXMs48x5y70uv9noQObT2sfBklWGbm2ClzWFUh/XCTS2ElPZ+xj61Asxocvc36P9M3RH7QWzl4N7ieZv5iRBBJS1twv8UFktn/Z6f9fJAoGBANAnV/p/SswD809N3tEcUqr3PBGzAkYOCG1q5wBNyi1AtmQ0C3hBXx6HcsX4cgNl3+3fgg6C3fSYdl0dFSXlqs7IpjXaethfC+4MIyocTPUiEiPs+pw1utqsNi/PiK4PDYX6EGs0tsTu8UOYfQMGG529t5wr34OQW8B0R9cYcNe3AoGBAKHjjSrrZRZGvW2l1SWzvNQEwMxchZZewS85eVTLoF8LD3V40RUZlaxGUPSD8P8dFZWgJBLcFbDwO01BtuUzF4kfLKdF1602M/howpvDbfXaasQqt57sSHuADyHQytLNjHhzMdi/vgpZWHgG/YVmQDaYE2sTeTjVXoQ8PFoFjf4HAoGALNWMmaP5VGA1dAttxtS26aQ/CADqqHQ1VHwGLYaT2ZNqtcKQBeLuvgCmtAWDaT/0L6RIux9s91YviHbPK06Ar/F/+3GHrDsssqVinZti6BnilmJgyGy6Rod5VGr7IaKUYxstlinQhDKDPPAHXTNfl2ZZugWpKwlY+ecR4j6db5kCgYEAjCf4mPbxLqcR6zMOZTTGP3zZ+lQD59qjQCJvNAWTE5X8zURLKAxdc6fxALCWXhgtDrx1XsqiEOz7OnixQp/IOZP+0db60eBCgEcabUZ2FcsCclFVZcbFPf7xmuIsJvOEMOfyeOgQPN97Y3cR2INdBqcE8MgMRDMeQDfyPDHg69MCgYEArWY0jU5aHJnoE8AcXePyVzJkF4cVwi5EtWsK8HQNXxoSwqQgCvnw7GhccFK8SSUM5p+ZVInb7GSBy7unO5GOQNMBv35nYS2pkqD41/J6FNmvLABROYU6V9/o4wPvQrn0i4TJ20PL3jzMsQ0v/Kr1WRNtFRrAqrthM+zgzrHiyDk=
-----END RSA PRIVATE KEY-----"""


public_key_string = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlwDCsbAQAyyQMe7xqRTARmZBtHEI50vxo7US95PkPBXpOjJV+tcQuntf+3j46TKljhUiXJRoScH3jIkCGG16q4jVqmN2xuoKk5W8CaIcslgC6ELqP97w+ZV5JckhpQrlfpnGl00hh+Jg2IQSKFXExIAG+eTYSLziBCwbSbW6U5LGnMqcmzlu/LzVLTJzXKM5MujKZcRwTiwvVW+ziUbNn4ec/6i1MB6I0dRwlN805NO6QiGS75K97MsTJI2mW+15szQYpSIQ7hqaiF1/08ms0lleF+fwwoX/AdqxQ9uXknQ1flkuqUYjvBpImZvCyTAb79DTL0PipaBTbS5GLxYNAwIDAQAB
-----END PUBLIC KEY-----"""


alipay = AliPay(
    appid=app_id,
    app_notify_url=None,
    # app_return_url='http://127.0.0.1:5000/',
    app_private_key_string=private_key_string,
    alipay_public_key_string=public_key_string,
    sign_type="RSA2",  # RSA 或者 RSA2
    debug=True
)


@app.route('/')
def index(user=None):
    user = session.get('user')
    products = get_all_products()
    for product in products:
        print(product)
    return render_template('index.html', products=products, user=user)


@app.route('/product/<int:product_id>')
def product_detail(product_id):
    user = session.get('user')
    product = get_product_by_id(product_id)
    comments = get_comments_by_product_id(product_id)
    likes_count = get_likes_count(product_id)
    dislikes_count = get_dislikes_count(product_id)
    comm = []
    for comment in comments:
        customer_name = get_customer_by_id(comment.customer_id).username
        comm.append({
            'customer_id': comment.customer_id,
            'content': comment.content,
            'customer_name': customer_name,
            'time': comment.time
        })

    return render_template('product_detail.html', product=product, user=user, comments=comm, likes_count=likes_count,
                           dislikes_count=dislikes_count)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm-password']
        account_type = request.form['account-type']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']

        if len(password) < 5:
            return jsonify({"error": "Password must be at least 5 characters long."})

        if password == confirm_password:
            if account_type == "Supplier":
                supplier = Supplier(None, username, password, email, address, phone)
                add_supplier(supplier)
                return jsonify({"success": True})
            else:
                cus = Customer(None, username, password, email, address, phone)
                add_customer(cus)
                return jsonify({"success": True})
        return jsonify({"error": "The two password are not same"})

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        account_type = request.form.get('account-type')
        if account_type == 'customer':
            user = get_customer_by_username(username)
        else:
            user = get_supplier_by_username(username)
        error_message = None
        if user is None:
            error_message = "Account doesn't exit."
        elif password != user.password:
            error_message = "Invalid password."
        if error_message:
            return render_template('login.html', error_message=error_message)
        session['user'] = user.__dict__
        if account_type == 'customer':
            return redirect(url_for('index'))
        else:
            return redirect(url_for('supplier_product_management'))
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('index'))


@app.route('/cart', methods=['GET', 'POST'])
def cart():
    user = session.get('user')
    user_id = session['user']['user_id']
    products_in_cart = get_products_in_cart(user_id)
    total_price = 0

    for item in products_in_cart:
        discount = item['product'].discount
        if discount is None:
            discount = 1

        discounted_price = item['product'].price * discount
        price = discounted_price * item['quantity']
        total_price += price

    return render_template('cart.html', products_in_cart=products_in_cart, total_price=total_price, user=user)


@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    user_id = session.get('user', {}).get('user_id')
    product_id = request.json['product_id']
    quantity = request.json.get('quantity', 1)
    if quantity == None:
        return jsonify({"error": "Product is temporarily out of inventory."}), 400

    add_product_to_cart(user_id, product_id, quantity)

    return jsonify({"success": "Product added to cart."})


@app.route('/update_cart_item', methods=['POST'])
def update_cart_item():
    user_id = session['user']['user_id']
    product_id = request.form['product_id']
    new_quantity = request.form['new_quantity']

    update_product_quantity_in_cart(user_id, product_id, new_quantity)
    return jsonify(success=True)


@app.route('/remove_cart_item', methods=['POST'])
def remove_cart_item():
    user_id = session['user']['user_id']
    product_id = request.form['product_id']

    remove_product_from_cart(user_id, product_id)
    return jsonify(success=True)


@app.route('/pay')
def pay():
    is_buy_now = request.args.get('is_buy_now', 'false') == 'true'
    product_id = request.args.get('product_id', None)
    quantity = request.args.get('quantity', None)

    if product_id is not None:
        product_id = int(product_id)
    if quantity is not None:
        quantity = int(quantity)

    user = session.get('user', {})
    user_id = session.get('user', {}).get('user_id')
    cart_items = get_cart_items(user_id)

    products_in_cart = []
    total_price = 0

    if is_buy_now and product_id and quantity:
        product = get_product_by_id(product_id)
        discount = product.discount if product.discount is not None else 1
        discounted_price = product.price * discount
        price = discounted_price * quantity
        total_price += price

        products_in_cart.append({
            'product': product,
            'quantity': quantity,
            'total_price': price
        })
    else:
        for item in cart_items:
            product = get_product_by_id(item.product_id)
            discount = product.discount if product.discount is not None else 1
            discounted_price = product.price * discount
            price = discounted_price * item.quantity
            total_price += price

            products_in_cart.append({
                'product': product,
                'quantity': item.quantity,
                'total_price': price
            })

    return render_template('pay.html', products_in_cart=products_in_cart, total_price=total_price, user=user,
                           is_buy_now=is_buy_now)


@app.route('/submit_payment', methods=['POST'])
def submit_payment():
    data = request.get_json()

    user_id = session['user']['user_id']
    payment_method = data['payment_method']
    name = data['name']
    address = data['address']
    phone = data['phone']
    is_buy_now = data['is_buy_now']
    cart_items = get_cart_items(user_id)
    out_trade_no = str(uuid.uuid4())
    if payment_method == 'alipay':
        if is_buy_now:
            product_id = data['product_id']
            quantity = data['quantity']
            product = get_product_by_id(product_id)
            discount = product.discount if product.discount is not None else 1
            status = 1
            time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if not is_inventory_sufficient(product_id, quantity):
                return jsonify({'error': 'Insufficient inventory'}), 400
            discounted_price = product.price * discount * quantity

            insert_order(user_id, product_id, product.supplier_id, quantity, status, discounted_price,
                         payment_method, time, name, address, phone, out_trade_no)
            update_product_inventory(product_id, quantity)

            order_string = alipay.api_alipay_trade_page_pay(
                out_trade_no=out_trade_no,
                total_amount=str(discounted_price),
                subject=product.name,
                return_url='http://127.0.0.1:5000/',
                notify_url="http://example.com/notify"
            )
            alipay_url = "https://openapi.alipaydev.com/gateway.do?" + order_string
            return jsonify({'alipay_url': alipay_url}), 200
        else:
            total_amount = 0
            for item in cart_items:
                product = get_product_by_id(item.product_id)
                discount = product.discount if product.discount is not None else 1
                status = 1
                time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                if not is_inventory_sufficient(item.product_id, item.quantity):
                    return jsonify(
                        {'error': f'Insufficient inventory for product {get_product_by_id(item.product_id).name}'}), 400
                discounted_price = product.price * discount * item.quantity
                insert_order(user_id, item.product_id, product.supplier_id, item.quantity, status, discounted_price,
                             payment_method, time, name, address, phone, out_trade_no)
                update_product_inventory(item.product_id, item.quantity)

                total_amount += discounted_price

            remove_cart_items(user_id)

            order_string = alipay.api_alipay_trade_page_pay(
                out_trade_no=out_trade_no,
                total_amount=str(total_amount),
                subject="Cart Checkout",
                return_url='http://127.0.0.1:5000/',
                notify_url="http://example.com/notify"
            )
            alipay_url = "https://openapi.alipaydev.com/gateway.do?" + order_string

            return jsonify({'alipay_url': alipay_url}), 200


@app.route('/pay_success')
def pay_success():
    return render_template('pay_success.html')


@app.route('/order')
def order():
    user_id = session['user']['user_id']
    user = session['user']

    orders = get_orders_by_user_id(user_id)

    order_details = []
    for order in orders:
        product = get_product_by_id(order.product_id)
        supplier = get_supplier_by_id(order.supplier_id)
        if order.status == 1:
            order.status = "To be shipped"
        elif order.status == 2:
            order.status = "Shipped"
        elif order.status == 3:
            order.status = "Completed"
        elif order.status == 4:
            order.status = "Cancelled"
        elif order.status == 0:
            order.status = "To be paid"
        order_details.append({
            'OrderID': order.order_id,
            'ProductName': product.name,
            'SupplierName': supplier.username,
            'Quantity': order.quantity,
            'Price': order.price,
            'Status': order.status,
            'Payment_method': order.payment_method,
            'Time': order.time,
            'Receiver_name': order.receiver_name,
            'Receiver_address': order.receiver_address,
            'Receiver_phone': order.receiver_phone,
        })
        # print(order.order_id, order.product_id, order.product_id)

    return render_template('order.html', user=user, orders=order_details)


@app.route('/add_comment', methods=['POST'])
def add_comment():
    user_id = session.get('user', {}).get('user_id')
    if not user_id:
        return jsonify({"error": "Please login first"})
    product_id = request.json['product_id']
    content = request.json['content']

    insert_comment(user_id, product_id, content)
    return jsonify({"success": "Comment added."})


@app.route('/toggle_like_dislike', methods=['POST'])
def toggle_like_dislike():
    user_id = session['user']['user_id']
    product_id = request.json['product_id']
    action = request.json['action']
    likes, dislikes = update_like_dislike(user_id, product_id, action)

    return jsonify({"likes": likes, "dislikes": dislikes})


@app.route('/products_by_category')
def products_by_category():
    category = request.args.get('category')
    if category == 'All':
        products = get_all_products()
        products_dict = [product.to_dict() for product in products]
        return jsonify(products_dict)
    products = get_products_by_category(category)
    products_dict = [product.to_dict() for product in products]
    return jsonify(products_dict)


@app.route('/search', methods=['GET'])
def search():
    search_query = request.args.get('query', '').strip()
    if not search_query:
        return jsonify({'error': 'Please provide a search query'})

    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute(
        "SELECT * FROM product WHERE name LIKE %s",
        (f"%{search_query}%",)
    )
    results = cursor.fetchall()
    cursor.close()
    connection.close()

    products = [dict(zip([column[0] for column in cursor.description], row)) for row in results]
    return jsonify({'products': products})


@app.route('/supplier_product_management', methods=['GET'])
def supplier_product_management():
    user = session.get('user')
    if not user:
        return redirect(url_for('login'))

    categories = get_all_categories()
    pro = []
    products = get_product_by_supplier_id(user['user_id'])
    for product in products:
        pro.append({
            "id": product.id,
            "name": product.name,
            "image": product.image,
            "description": product.description,
            "price": product.price,
            "inventory": product.inventory,
            "supplier_id": product.supplier_id,
            "category_id": product.category_id,
            "discount": product.discount,
            "discount_time": product.discount_time,
            "category": get_category_by_id(product.category_id).name
        })
    return render_template('supplier_product_management.html', user=user, categories=categories, products=pro)


@app.route('/add_product', methods=['POST'])
def add_product():
    name = request.form['product-name']
    price = request.form['product-price']
    inventory = request.form['product-inventory']
    description = request.form['product-description']
    image = request.files['product-image']
    supplier_id = session['user']['user_id']
    category_id = request.form['product-category']
    discount = request.form['product-discount']
    discount_time = request.form['product-discount-time']

    if discount == '':
        discount = None
    if discount_time == '':
        discount_time = None
    image_path = save_image(image).replace("\\", "/")

    add_product_to_database(name, price, inventory, description, image_path, supplier_id, category_id, discount,
                            discount_time)

    return jsonify({'success': True})


@app.route('/delete_product/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    image_path = delete_product_from_database(product_id)

    if image_path:
        full_image_path = os.path.join(os.getcwd(), 'static', image_path)
        # print(full_image_path)

        if os.path.exists(full_image_path):
            os.remove(full_image_path)
            return jsonify({'success': True})
        else:
            error_message = f"Image file not found at {full_image_path}"
            return jsonify({'success': False, 'message': error_message})
    else:
        return jsonify({'success': True})


@app.route('/get_product/<int:product_id>', methods=['GET'])
def get_product(product_id):
    product = get_product_by_id(product_id)
    return jsonify(product.to_dict())


@app.route('/update_product/<int:product_id>', methods=['POST'])
def update_product(product_id):
    name = request.form['product-name']
    price = request.form['product-price']
    inventory = request.form['product-inventory']
    description = request.form['product-description']
    image = request.files.get('product-image')
    category_id = request.form['product-category']
    discount = request.form['product-discount']
    discount_time = request.form['product-discount-time']

    if discount == '':
        discount = None
    if discount_time == '':
        discount_time = None
    if image:
        image_path = save_image(image).replace("\\", "/")
    else:
        product = get_product_by_id(product_id)
        image_path = product.image

    update_product_in_database(product_id, name, price, inventory, description, image_path, category_id, discount,
                               discount_time)
    return jsonify({'success': True})


@app.route('/supplier_order_management', methods=['GET'])
def supplier_order_management():
    user = session.get('user')
    if not user:
        return redirect(url_for('login'))

    supplier_id = user['user_id']
    orders = get_orders_by_supplier_id(supplier_id)
    orders_with_customer_name = add_customer_name_to_orders(orders)

    return render_template('supplier_order_management.html', user=user,
                           orders_with_buyer_name=orders_with_customer_name)




@app.route('/edit_order/<int:order_id>', methods=['POST'])
def edit_order(order_id):
    status = request.json.get('status')
    success = update_order_status(order_id, status)

    if success:
        return jsonify({"success": True})
    else:
        return jsonify({"success": False, "message": "Order not found or status not changed"})



if __name__ == '__main__':
    app.run()
